# WhoopSim

Plug in controller/drone transmitter to be able to move around as drone.
(Ive only tested bluetooth with an xbox controller & plugging in a radiomaster 
pocket)

Im using the freetype library for text rendering, like what was instructed in the
learnopengl resource. So there might be dependancy issues if thats not installed
not sure however...
